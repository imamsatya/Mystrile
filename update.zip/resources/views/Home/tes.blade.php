{{-- {{$setatribut}}
{{$hargabarang}}
{{$sewaalat}}
{{$jasakonstruksi}} --}}
{{ json_encode($metadata)}}