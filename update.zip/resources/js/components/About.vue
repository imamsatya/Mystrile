<template>
    <div>
        <!-- <h1>Halo</h1> -->   
           
        <v-container bg fill-height grid-list-md>
            <v-layout row wrap align-center>
                <vs-row vs-justify="center">
                    <vs-col type="flex" vs-justify="center" vs-align="center" vs-w="12">
                        <vs-card actionable class="cardx">
                            <div slot="header">
                                <br>

                                <img :src="'MystrileV1_1.png'" width="100px" height="100px" alt="" srcset="">

                                <br>
                                <br>

                                <vs-divider border-style="dashed" color="danger">
                                    <h2 style="color:#D81B60;">
                                        Mystrile
                                    </h2>
                                      
                                </vs-divider>


                            </div>

                            <div>
                                <p>Aplikasi ini dibuat untuk mempermudah petugas IKK dalam melakukan pendataan di lapangan.
            Proyek ini dibangun bersama oleh : <br>
            Aditya Sudyana, S.S.T. <br>
            Imam Satya Wedhatama S.Tr.Stat
            <br><br>
            Dari Kabupaten Tolitoli</p>
                            </div>

                        </vs-card>
                    </vs-col>
                </vs-row>
            </v-layout>
        </v-container>
    </div>



</template>
