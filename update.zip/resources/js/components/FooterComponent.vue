<template>
  <v-footer
    class="grey darken-3"
    height="auto"
  >
  <v-layout
      justify-center
      row
      wrap
    >
    <v-card
      flat
      tile
      class="grey darken-3 white--text text-xs-center"
    >

      <v-card-text class="white--text pt-0">
        <p></p>
        <p class="white--text pt-0"> Luaskan ilmu, luaskan manfaat <br>
        [ ] dengan &hearts; di Toli-toli</p>
        
      </v-card-text>

      <v-divider></v-divider>

      <v-card-text class="white--text">
        &copy;2019 — Aditya Sudyana  & Imam Satya Wedhatama
      </v-card-text>
    </v-card>
  </v-layout>
  </v-footer>
</template>

