<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SewaAlat extends Model
{
    //
}
