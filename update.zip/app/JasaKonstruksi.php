<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class JasaKonstruksi extends Model
{
    //
}
