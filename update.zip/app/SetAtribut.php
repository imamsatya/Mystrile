<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SetAtribut extends Model
{
    //
}
