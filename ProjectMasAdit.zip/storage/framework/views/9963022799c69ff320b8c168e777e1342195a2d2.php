<?php /* C:\MAMP\htdocs\ProjectMasAdit\resources\views/home/beranda.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div>
        
<beranda-c :hargabarangs="<?php echo e($hargabarangs); ?>" :sewaalats="<?php echo e($sewaalats); ?>" :jasakonstruksis="<?php echo e($jasakonstruksis); ?>" :id="<?php echo e($id); ?>"></beranda-c>
        
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>