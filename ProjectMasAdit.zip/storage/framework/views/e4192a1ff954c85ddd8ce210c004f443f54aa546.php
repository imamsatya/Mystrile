<?php /* C:\MAMP\htdocs\ProjectMasAdit\resources\views/Atribut/atribut-c.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div>
        
        <atribut-c></atribut-c>
        
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>