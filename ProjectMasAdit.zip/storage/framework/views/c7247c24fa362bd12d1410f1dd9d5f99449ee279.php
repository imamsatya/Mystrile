<?php /* C:\MAMP\htdocs\ProjectMasAdit\resources\views/home/menu.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div>
        
       <h1>asdasd</h1>
        
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>