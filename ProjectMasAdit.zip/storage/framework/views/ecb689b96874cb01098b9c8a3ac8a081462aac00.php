<?php /* C:\MAMP\htdocs\ProjectMasAdit\resources\views/Beranda/jasakonstruksi.blade.php */ ?>
<?php $__env->startSection('content'); ?>
<div>
        
        <jasakonstruksicreate-c :id="<?php echo e($id); ?>"></jasakonstruksicreate-c>
        
</div>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>