@extends('layouts.app')

@section('content')
<div>
        
        <atribut-c></atribut-c>
        
</div>
    
@endsection