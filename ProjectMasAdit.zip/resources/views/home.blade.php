@extends('layouts.app')

@section('content')
<div>
        
<home-c :datas="{{$setatributs}}" ></home-c>
        
</div>
    
@endsection