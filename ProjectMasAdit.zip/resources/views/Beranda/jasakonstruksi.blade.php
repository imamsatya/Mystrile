@extends('layouts.app')

@section('content')
<div>
        
        <jasakonstruksicreate-c :id="{{$id}}"></jasakonstruksicreate-c>
        
</div>
    
@endsection