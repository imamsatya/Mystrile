@extends('layouts.app')

@section('content')
<div>
        
        <hargabarangcreate-c :id="{{$id}}"></hargabarangcreate-c>
        
</div>
    
@endsection