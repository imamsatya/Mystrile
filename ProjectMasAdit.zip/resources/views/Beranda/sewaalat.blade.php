@extends('layouts.app')

@section('content')
<div>
        
        <sewaalatcreate-c :id="{{$id}}"></sewaalatcreate-c>
        
</div>
    
@endsection